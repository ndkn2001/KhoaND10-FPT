# KhoaND10 FPT — dự án Android

## Hiện trạng
Đây là **mã nguồn dự án Android**, chưa phải APK đã biên dịch hoặc kiểm thử trên điện thoại.
Môi trường tạo dự án hiện không có Android SDK/Gradle nên không thể xác nhận một APK cài đặt được tại đây.

## Chức năng trong bản nền 1.0
- Camera sau bằng CameraX, phân tích khung hình trực tiếp bằng Google ML Kit Text Recognition.
- Tách thử Model, MAC, Serial/SN, SSID từ văn bản OCR; cho phép sửa trước khi lưu.
- Lịch sử lưu cục bộ trên điện thoại, tìm kiếm và xóa bản ghi.
- Đọc thông tin Wi-Fi cơ bản.
- Quét giới hạn các cổng phổ biến trong mạng LAN hiện tại.
- Mở trang quản trị gateway/router trong trình duyệt.

## Chức năng chưa hoàn thiện
- Cấu hình PPPoE, đổi SSID/mật khẩu, SSH và các lệnh quản trị riêng của từng hãng chưa được triển khai.
  Những thao tác này cần giao thức/API chính xác của từng model và thông tin xác thực hợp lệ.
- Chưa có kiểm thử thực tế trên thiết bị Android; OCR có thể cần tinh chỉnh theo từng loại tem.
- Bản này chưa có export CSV/PDF, flash toggle, Wi-Fi channel survey hay tự động đồng bộ cloud.

## Mở và build APK
1. Cài Android Studio bản ổn định và Android SDK Platform 35.
2. Mở thư mục `KhoaND10_FPT_Android` bằng Android Studio.
3. Dùng JDK 17; chờ Gradle Sync tải dependencies.
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug dự kiến ở `app/build/outputs/apk/debug/app-debug.apk`.

Hoặc trên máy có Android SDK và Gradle:
```bash
gradle assembleDebug
```

## Quyền riêng tư và an toàn
- Camera chỉ dùng cho OCR tại thiết bị.
- Lịch sử lưu trong SharedPreferences riêng của ứng dụng.
- Quét LAN chỉ thực hiện khi người dùng nhấn nút và trên mạng nội bộ đang kết nối.
- Chỉ sử dụng chức năng mạng/quản trị với thiết bị và mạng bạn được phép quản lý.

## Định danh
- Tên: KhoaND10 FPT
- Application ID: `com.khoand10.fpt`
- Version: `1.0.0`
