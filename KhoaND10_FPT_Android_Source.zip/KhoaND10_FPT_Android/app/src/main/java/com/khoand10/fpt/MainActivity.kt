package com.khoand10.fpt

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class DeviceRecord(
    val model: String, val mac: String, val serial: String, val ssid: String, val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KhoaApp() }
    }
}

@Composable
fun KhoaApp() {
    var page by remember { mutableStateOf("Trang chủ") }
    val ctx = LocalContext.current
    val records = remember { mutableStateListOf<DeviceRecord>().apply { addAll(loadRecords(ctx)) } }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF0756A5))) {
        Scaffold(
            topBar = { TopAppBarSimple(page) },
            bottomBar = {
                NavigationBar {
                    listOf("Trang chủ", "Quét tem", "Lịch sử", "Mạng").forEach { label ->
                        NavigationBarItem(
                            selected = page == label,
                            onClick = { page = label },
                            icon = { Icon(
                                when(label) {
                                    "Quét tem" -> Icons.Default.CameraAlt
                                    "Lịch sử" -> Icons.Default.History
                                    "Mạng" -> Icons.Default.Wifi
                                    else -> Icons.Default.Home
                                }, contentDescription = label
                            ) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when(page) {
                    "Quét tem" -> ScannerPage { record ->
                        records.add(0, record); saveRecords(ctx, records); page = "Lịch sử"
                    }
                    "Lịch sử" -> HistoryPage(records, onDelete = { records.remove(it); saveRecords(ctx, records) })
                    "Mạng" -> NetworkPage()
                    else -> HomePage(
                        onScan = { page = "Quét tem" },
                        onHistory = { page = "Lịch sử" },
                        onNetwork = { page = "Mạng" },
                        onRouter = { openRouterAdmin(ctx) }
                    )
                }
            }
        }
    }
}

@Composable
fun TopAppBarSimple(title: String) {
    Surface(shadowElevation = 3.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=15.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.Router, contentDescription=null, tint=MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text("KhoaND10 FPT", style=MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            Text(title, style=MaterialTheme.typography.labelMedium, color=MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun HomePage(onScan:()->Unit, onHistory:()->Unit, onNetwork:()->Unit, onRouter:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer), shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("CÔNG CỤ KỸ THUẬT", style=MaterialTheme.typography.labelLarge)
                    Text("Quản lý thiết bị mạng", style=MaterialTheme.typography.headlineSmall)
                    Text("Quét tem modem • Nhận diện OCR • Lưu lịch sử", style=MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick=onScan, modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.DocumentScanner, null); Spacer(Modifier.width(8.dp)); Text("BẮT ĐẦU QUÉT TEM")
                    }
                }
            }
        }
        item { FeatureCard("Lịch sử thiết bị", "Xem và tìm các modem đã quét", Icons.Default.History, onHistory) }
        item { FeatureCard("Phân tích mạng", "Thông tin Wi-Fi, gateway và kiểm tra kết nối", Icons.Default.Wifi, onNetwork) }
        item { FeatureCard("Quản trị modem", "Mở trang quản trị modem trong mạng nội bộ", Icons.Default.SettingsEthernet, onRouter) }
        item {
            Text("Lưu ý: Ứng dụng lưu dữ liệu quét trên điện thoại. Chỉ quản trị thiết bị/mạng mà bạn được phép sử dụng.", style=MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun FeatureCard(title:String, desc:String, icon:androidx.compose.ui.graphics.vector.ImageVector, click:()->Unit) {
    Card(onClick=click, modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(icon, null, tint=MaterialTheme.colorScheme.primary, modifier=Modifier.size(34.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title, style=MaterialTheme.typography.titleMedium); Text(desc, style=MaterialTheme.typography.bodySmall) }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
fun ScannerPage(onSave:(DeviceRecord)->Unit) {
    val ctx= LocalContext.current
    val lifecycleOwner= LocalLifecycleOwner.current
    var permission by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) }
    var recognized by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    var serial by remember { mutableStateOf("") }
    var ssid by remember { mutableStateOf("") }
    var cameraError by remember { mutableStateOf("") }
    val permissionLauncher= rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permission=it }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Quét tem modem", style=MaterialTheme.typography.headlineSmall)
        if (!permission) {
            Text("Cần cấp quyền Camera để quét tem.")
            Button(onClick={permissionLauncher.launch(Manifest.permission.CAMERA)}) { Text("Cấp quyền camera") }
        } else {
            CameraPreview(
                lifecycleOwner= lifecycleOwner,
                onText={ text ->
                    recognized=text
                    val parsed=parseLabel(text)
                    if(parsed.first.isNotBlank()) model=parsed.first
                    if(parsed.second.isNotBlank()) mac=parsed.second
                    if(parsed.third.isNotBlank()) serial=parsed.third
                    if(parsed.fourth.isNotBlank()) ssid=parsed.fourth
                },
                onError={cameraError=it}
            )
            if(cameraError.isNotBlank()) Text(cameraError, color=MaterialTheme.colorScheme.error)
        }
        Text("Đưa tem modem vào khung hình, giữ máy ổn định và đủ sáng.", style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(model,{model=it},label={Text("Model")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(mac,{mac=it},label={Text("MAC")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(serial,{serial=it},label={Text("Serial / S/N")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(ssid,{ssid=it},label={Text("SSID")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Button(
            onClick={
                val date=SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(Date())
                onSave(DeviceRecord(model.trim(),mac.trim().uppercase(),serial.trim(),ssid.trim(),date))
            },
            enabled=model.isNotBlank() || mac.isNotBlank(),
            modifier=Modifier.fillMaxWidth()
        ) { Icon(Icons.Default.Save,null); Spacer(Modifier.width(8.dp)); Text("LƯU THIẾT BỊ") }
        if(recognized.isNotBlank()) Text("Văn bản OCR: ${recognized.take(220)}", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun CameraPreview(lifecycleOwner: androidx.lifecycle.LifecycleOwner, onText:(String)->Unit, onError:(String)->Unit) {
    val ctx=LocalContext.current
    val executor= remember { Executors.newSingleThreadExecutor() }
    val busy= remember { AtomicBoolean(false) }
    AndroidView(
        modifier=Modifier.fillMaxWidth().height(250.dp),
        factory={ context ->
            val view=PreviewView(context)
            val providerFuture=ProcessCameraProvider.getInstance(context)
            providerFuture.addListener({
                try {
                    val provider=providerFuture.get()
                    val preview=Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                    val analysis=ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                    val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    analysis.setAnalyzer(executor) { proxy ->
                        val image=proxy.image
                        if(image==null || !busy.compareAndSet(false,true)) { proxy.close() }
                        else {
                            val input=InputImage.fromMediaImage(image,proxy.imageInfo.rotationDegrees)
                            recognizer.process(input)
                                .addOnSuccessListener { result -> if(result.text.isNotBlank()) onText(result.text) }
                                .addOnFailureListener { onError("Không nhận diện được chữ. Hãy điều chỉnh ánh sáng/góc chụp.") }
                                .addOnCompleteListener { busy.set(false); proxy.close() }
                        }
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis)
                } catch(e:Exception) { onError("Không mở được camera: ${e.localizedMessage ?: "lỗi không xác định"}") }
            },ContextCompat.getMainExecutor(context))
            view
        }
    )
}

fun parseLabel(text:String): Quad {
    val normalized=text.uppercase().replace('O','0').replace('I','1')
    val macRegex=Regex("""(?i)(?:[0-9A-F]{2}[:-]){5}[0-9A-F]{2}|\\b[0-9A-F]{12}\\b""")
    val mac=macRegex.find(text)?.value?.replace(Regex("[^0-9A-Fa-f]"),"")?.uppercase().orEmpty()
    val lines=text.lines().map{it.trim()}.filter{it.isNotBlank()}
    val model=lines.firstOrNull { line ->
        val u=line.uppercase()
        (u.contains("AX") || u.contains("ZX") || u.contains("HG")) && Regex("[A-Z]{1,4}[- ]?\\d{3,5}",RegexOption.IGNORE_CASE).containsMatchIn(u)
    }?.replace(Regex("""(?i)^MODEL\\s*[:：]?\\s*"""),"")?.trim().orEmpty()
    val sn=Regex("""(?i)(?:S/?N|SERIAL(?:\\s*NO)?)[\\s:#-]*([A-Z0-9-]{6,})""").find(text)?.groupValues?.getOrNull(1).orEmpty()
    val wifi=Regex("""(?i)(?:SSID|WIFI\\s*NAME)[\\s:#-]*(.{3,32})""").find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    return Quad(model,mac,sn,wifi)
}
data class Quad(val first:String,val second:String,val third:String,val fourth:String)

@Composable
fun HistoryPage(records:List<DeviceRecord>, onDelete:(DeviceRecord)->Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Lịch sử quét",style=MaterialTheme.typography.headlineSmall)
        OutlinedTextField(query,{query=it},label={Text("Tìm Model hoặc MAC")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Spacer(Modifier.height(8.dp))
        val filtered=records.filter { it.model.contains(query,true) || it.mac.contains(query,true) || it.serial.contains(query,true) }
        if(filtered.isEmpty()) Text("Chưa có dữ liệu phù hợp.",modifier=Modifier.padding(16.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(filtered) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(item.model.ifBlank{"Chưa rõ Model"},style=MaterialTheme.typography.titleMedium,modifier=Modifier.weight(1f))
                            IconButton(onClick={onDelete(item)}) { Icon(Icons.Default.Delete,null) }
                        }
                        Text("MAC: ${item.mac.ifBlank{"—"}}")
                        Text("S/N: ${item.serial.ifBlank{"—"}}")
                        Text("SSID: ${item.ssid.ifBlank{"—"}}")
                        Text(item.date,style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkPage() {
    val ctx=LocalContext.current
    var result by remember { mutableStateOf("Nhấn kiểm tra để đọc thông tin mạng hiện tại.") }
    var scanResult by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Phân tích mạng",style=MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Text(result,Modifier.padding(16.dp)) }
        Button(onClick={
            result=wifiInfo(ctx)
        },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi,null); Spacer(Modifier.width(8.dp)); Text("LẤY THÔNG TIN WI-FI") }
        Button(enabled=!busy,onClick={
            busy=true; scanResult="Đang kiểm tra một số cổng phổ biến trong mạng nội bộ..."
            scope.launch {
                scanResult=withContext(Dispatchers.IO){ scanLan(ctx) }
                busy=false
            }
        },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Search,null); Spacer(Modifier.width(8.dp)); Text(if(busy)"ĐANG QUÉT..." else "QUÉT THIẾT BỊ LAN") }
        Text(scanResult,style=MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick={ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))},modifier=Modifier.fillMaxWidth()) { Text("MỞ CÀI ĐẶT WI-FI") }
        Text("Quét LAN chỉ kiểm tra các cổng phổ biến trên mạng nội bộ hiện tại; kết quả không thay thế công cụ kiểm thử bảo mật chuyên dụng.",style=MaterialTheme.typography.bodySmall)
    }
}

fun wifiInfo(ctx:Context):String {
    return try {
        val wm=ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info=wm.connectionInfo
        val ip=info.ipAddress
        val ipText=listOf(ip and 255,(ip shr 8) and 255,(ip shr 16) and 255,(ip shr 24) and 255).joinToString(".")
        "SSID: ${info.ssid ?: "Không rõ"}\\nBSSID: ${info.bssid ?: "Không rõ"}\\nIP: $ipText\\nRSSI: ${info.rssi} dBm\\nTần số: ${info.frequency} MHz\\nLink speed: ${info.linkSpeed} Mbps"
    } catch(e:Exception) { "Không đọc được thông tin Wi-Fi: ${e.localizedMessage}" }
}

fun scanLan(ctx:Context):String {
    return try {
        val wm=ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip=wm.connectionInfo.ipAddress
        if(ip==0) return "Điện thoại chưa kết nối Wi-Fi."
        val base="${ip and 255}.${(ip shr 8) and 255}.${(ip shr 16) and 255}"
        val found=mutableListOf<String>()
        for(host in 1..254) {
            val address="$base.$host"
            for(port in listOf(80,443,22,8080)) {
                try {
                    Socket().use { s -> s.connect(java.net.InetSocketAddress(address,port),90) }
                    found.add("$address — cổng $port mở")
                    break
                } catch(_:Exception) {}
            }
        }
        if(found.isEmpty()) "Không phát hiện thiết bị phản hồi trên các cổng đã kiểm tra."
        else "Thiết bị/cổng phản hồi:\\n"+found.joinToString("\\n")
    } catch(e:Exception) { "Lỗi quét LAN: ${e.localizedMessage}" }
}

fun openRouterAdmin(ctx:Context) {
    try {
        val wm=ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip=wm.connectionInfo.ipAddress
        val gateway=try {
            val dhcp=wm.dhcpInfo.gateway
            "${dhcp and 255}.${(dhcp shr 8) and 255}.${(dhcp shr 16) and 255}.${(dhcp shr 24) and 255}"
        } catch(_:Exception) { "" }
        val url=if(gateway.isNotBlank() && gateway!="0.0.0.0") "http://$gateway" else "http://192.168.1.1"
        ctx.startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)))
    } catch(_:Exception) {
        ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
    }
}

fun loadRecords(ctx:Context):List<DeviceRecord> {
    return try {
        val a=JSONArray(ctx.getSharedPreferences("device_history",Context.MODE_PRIVATE).getString("records","[]"))
        (0 until a.length()).map { i ->
            val o=a.getJSONObject(i)
            DeviceRecord(o.optString("model"),o.optString("mac"),o.optString("serial"),o.optString("ssid"),o.optString("date"))
        }
    } catch(_:Exception) { emptyList() }
}
fun saveRecords(ctx:Context,records:List<DeviceRecord>) {
    val a=JSONArray()
    records.forEach { r ->
        a.put(JSONObject().put("model",r.model).put("mac",r.mac).put("serial",r.serial).put("ssid",r.ssid).put("date",r.date))
    }
    ctx.getSharedPreferences("device_history",Context.MODE_PRIVATE).edit().putString("records",a.toString()).apply()
}
